export * from "./auth.actions";
export * from "./auth.reducers";
export * from "./auth.models";
export * from "./auth.effects";
export * from "./auth.selectors";
export declare const NAME_OF_ACTION_REGISTER = "register";
