import { Reducer } from "redux";
import { ReferState } from "./refer.models";
import { ReferAction } from "./refer.actions";
export declare const refer: Reducer<ReferState, ReferAction>;
