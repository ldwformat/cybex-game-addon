import * as React from "react";
import { StyledComponentProps } from "@material-ui/core";
export declare const Login: import("react-redux").ConnectedComponentClass<React.ComponentType<Pick<any, string | number | symbol> & StyledComponentProps<"paper">>, Pick<Pick<any, string | number | symbol> & StyledComponentProps<"paper">, string | number | symbol>>;
