import * as React from "react";
import { StyledComponentProps } from "@material-ui/core";
export declare const ReferRule: React.ComponentType<Pick<StyledComponentProps<"root" | "copyCard" | "innerWrapper" | "buttonRoot">, "innerRef"> & StyledComponentProps<string>>;
