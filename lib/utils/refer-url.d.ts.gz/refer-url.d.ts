export declare const getReferUrl: (path: string, accountName: string) => string;
export declare const resolveNameFromReferUrl: (path: string) => string;
